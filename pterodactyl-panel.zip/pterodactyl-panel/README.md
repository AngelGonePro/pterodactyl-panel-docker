# Pterodactyl Panel

Self-contained panel with its own MariaDB and Redis. Everything is configured in `.env`.

## Install (first time)

Run from your home folder. This installs through `deploy-update.sh` itself, so the update baseline is recorded from day one and later updates apply cleanly:
```
cd ~ && \
curl -fsSL -o /tmp/pterodactyl-panel.zip https://github.com/AngelGonePro/pterodactyl-panel-docker/raw/refs/heads/main/pterodactyl-panel.zip && \
python3 -c "import zipfile; open('/tmp/deploy-update.sh','wb').write(zipfile.ZipFile('/tmp/pterodactyl-panel.zip').read('pterodactyl-panel/deploy-update.sh'))" && \
sh /tmp/deploy-update.sh https://github.com/AngelGonePro/pterodactyl-panel-docker/raw/refs/heads/main/pterodactyl-panel.zip pterodactyl-panel && \
cp /tmp/deploy-update.sh pterodactyl-panel/ && chmod +x pterodactyl-panel/*.sh && rm -f /tmp/pterodactyl-panel.zip /tmp/deploy-update.sh
```
```
nano ~/pterodactyl-panel/.env
```
```
cd ~/pterodactyl-panel && docker compose up -d
docker compose exec panel php artisan p:user:make
```

## Update from GitHub (keeps your .env and data)

One line — pulls the new files, the new images, and restarts:
```
cd ~/pterodactyl-panel && ./deploy-update.sh https://github.com/AngelGonePro/pterodactyl-panel-docker/raw/refs/heads/main/pterodactyl-panel.zip . && docker compose pull && docker compose up -d --remove-orphans
```
`deploy-update.sh` never touches `.env` or the database/volumes. It appends any new `.env` keys at the bottom for you to review, and leaves any file you hand-edited alone (it reports those instead).

## Resource limits

Set in `.env`: `PANEL_MEM_LIMIT` / `PANEL_CPUS`, `DB_MEM_LIMIT` / `DB_CPUS`, `CACHE_MEM_LIMIT` / `CACHE_CPUS`. Swap is disabled, so a container that hits its memory cap restarts instead of dragging the host down. After editing: `docker compose up -d`. Check live use with `docker stats --no-stream`.

## Notes

- Multi-user is native: add accounts under **Admin → Users**, assign servers or sub-users per server.
- Behind a reverse proxy, set `TRUSTED_PROXIES` in `.env` and point the proxy at `PANEL_HTTP_PORT`.
- Unexplained 500 on a fresh install: `docker compose exec panel php artisan optimize:clear`. To see the real error, set `APP_DEBUG=true` in `.env`, `docker compose up -d`, reproduce, then set it back.
