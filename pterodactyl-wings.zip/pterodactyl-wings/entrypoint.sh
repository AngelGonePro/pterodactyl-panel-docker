#!/bin/sh
set -e

: "${WINGS_UUID:?WINGS_UUID is not set in .env}"
: "${WINGS_TOKEN_ID:?WINGS_TOKEN_ID is not set in .env}"
: "${WINGS_TOKEN:?WINGS_TOKEN is not set in .env}"
: "${PANEL_URL:?PANEL_URL is not set in .env}"

WINGS_SSL_ENABLED="${WINGS_SSL_ENABLED:-false}"
WINGS_USERNAME="${WINGS_USERNAME:-pterodactyl}"
TZ="${TZ:-UTC}"

mkdir -p /etc/pterodactyl

cat > /etc/pterodactyl/config.yml <<CONFEOF
app_name: Pterodactyl
debug: false
uuid: ${WINGS_UUID}
token_id: ${WINGS_TOKEN_ID}
token: ${WINGS_TOKEN}
ignore_panel_config_updates: true

api:
  host: 0.0.0.0
  port: 8080
  ssl:
    enabled: ${WINGS_SSL_ENABLED}
    cert: /etc/letsencrypt/live/${WINGS_FQDN}/fullchain.pem
    key: /etc/letsencrypt/live/${WINGS_FQDN}/privkey.pem
  upload_limit: 100
  trusted_proxies: []
  disable_remote_download: false

system:
  root_directory: /var/lib/pterodactyl
  log_directory: /var/log/pterodactyl
  data: /var/lib/pterodactyl/volumes
  archive_directory: /var/lib/pterodactyl/archives
  backup_directory: /var/lib/pterodactyl/backups
  tmp_directory: /tmp/pterodactyl
  username: ${WINGS_USERNAME}
  timezone: ${TZ}

docker:
  network:
    name: pterodactyl_nw
    driver: bridge

remote: ${PANEL_URL}
remote_query:
  timeout: 30
  boot_servers_per_page: 50

allowed_mounts: []
allowed_origins:
  - ${PANEL_URL}
CONFEOF

exec /usr/bin/wings --config /etc/pterodactyl/config.yml
