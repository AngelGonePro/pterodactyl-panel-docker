#!/bin/sh
set -e

: "${WINGS_UUID:?WINGS_UUID is not set in .env}"
: "${WINGS_TOKEN_ID:?WINGS_TOKEN_ID is not set in .env}"
: "${WINGS_TOKEN:?WINGS_TOKEN is not set in .env}"
: "${PANEL_URL:?PANEL_URL is not set in .env}"

WINGS_SSL_ENABLED="${WINGS_SSL_ENABLED:-false}"
WINGS_USERNAME="${WINGS_USERNAME:-pterodactyl}"
TZ="${TZ:-UTC}"

mkdir -p /etc/pterodactyl

# Build the allowed_origins YAML list from PANEL_URL plus any space-separated
# extra origins in WINGS_EXTRA_ORIGINS (e.g. other domains/proxies you load
# the panel from in a browser). Each becomes its own "  - <origin>" line.
ORIGINS_YAML="  - ${PANEL_URL}"
if [ -n "${WINGS_EXTRA_ORIGINS:-}" ]; then
  for origin in ${WINGS_EXTRA_ORIGINS}; do
    ORIGINS_YAML="${ORIGINS_YAML}
  - ${origin}"
  done
fi

# Build the trusted_proxies YAML list from space-separated IPs/CIDRs in
# WINGS_TRUSTED_PROXIES. Without this, Wings trusts NO upstream by default
# and treats whichever proxy connects to it directly as the "real" client
# IP for every single request — every user looks identical to Wings,
# admin or not, which is what causes permission/session issues for
# non-admins specifically when Wings sits behind a reverse proxy or tunnel.
TRUSTED_PROXIES_YAML=" []"
if [ -n "${WINGS_TRUSTED_PROXIES:-}" ]; then
  TRUSTED_PROXIES_YAML=""
  for proxy in ${WINGS_TRUSTED_PROXIES}; do
    TRUSTED_PROXIES_YAML="${TRUSTED_PROXIES_YAML}
  - ${proxy}"
  done
fi

cat > /etc/pterodactyl/config.yml <<CONFEOF
app_name: Pterodactyl
debug: false
uuid: ${WINGS_UUID}
token_id: ${WINGS_TOKEN_ID}
token: ${WINGS_TOKEN}
ignore_panel_config_updates: true

api:
  host: 0.0.0.0
  port: 8080
  ssl:
    enabled: ${WINGS_SSL_ENABLED}
    cert: /etc/letsencrypt/live/${WINGS_FQDN}/fullchain.pem
    key: /etc/letsencrypt/live/${WINGS_FQDN}/privkey.pem
  upload_limit: 100
  trusted_proxies:${TRUSTED_PROXIES_YAML}
  disable_remote_download: false

system:
  root_directory: /var/lib/pterodactyl
  log_directory: /var/log/pterodactyl
  data: /var/lib/pterodactyl/volumes
  archive_directory: /var/lib/pterodactyl/archives
  backup_directory: /var/lib/pterodactyl/backups
  tmp_directory: /tmp/pterodactyl
  username: ${WINGS_USERNAME}
  timezone: ${TZ}

docker:
  network:
    interface: 10.99.0.1
    name: pterodactyl_nw
    ispn: false
    driver: bridge
    network_mode: pterodactyl_nw
    is_internal: false
    enable_icc: true
    network_mtu: 1500
    dns:
      - 1.1.1.1
      - 1.0.0.1
    interfaces:
      v4:
        subnet: 10.99.0.0/16
        gateway: 10.99.0.1

remote: ${PANEL_URL}
remote_query:
  timeout: 30
  boot_servers_per_page: 50

allowed_mounts: []
allowed_origins:
${ORIGINS_YAML}
CONFEOF

echo "config.yml generated for node ${WINGS_UUID}"
