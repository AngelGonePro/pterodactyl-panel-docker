# Pterodactyl Wings

Wings node daemon. Everything is configured in `.env`; `config.yml` is generated from it on every start by a one-shot `wings-config` container, so you never edit that file.

## Install (first time)

Run from your home folder. This installs through `deploy-update.sh` itself, so the update baseline is recorded from day one and later updates apply cleanly:
```
cd ~ && \
curl -fsSL -o /tmp/pterodactyl-wings.zip https://github.com/AngelGonePro/pterodactyl-panel-docker/raw/refs/heads/main/pterodactyl-wings.zip && \
python3 -c "import zipfile; open('/tmp/deploy-update.sh','wb').write(zipfile.ZipFile('/tmp/pterodactyl-wings.zip').read('pterodactyl-wings/deploy-update.sh'))" && \
sh /tmp/deploy-update.sh https://github.com/AngelGonePro/pterodactyl-panel-docker/raw/refs/heads/main/pterodactyl-wings.zip pterodactyl-wings && \
cp /tmp/deploy-update.sh pterodactyl-wings/ && chmod +x pterodactyl-wings/*.sh && rm -f /tmp/pterodactyl-wings.zip /tmp/deploy-update.sh
```
```
nano ~/pterodactyl-wings/.env
```
Fill in `WINGS_UUID`, `WINGS_TOKEN_ID`, `WINGS_TOKEN` (panel: Admin → Nodes → your node → Configuration) and `PANEL_URL`. Create the host directories once (host and container paths must match):
```
sudo mkdir -p /etc/pterodactyl /var/lib/pterodactyl /var/log/pterodactyl /tmp/pterodactyl
sudo chown -R 988:988 /var/lib/pterodactyl /var/log/pterodactyl /tmp/pterodactyl
cd ~/pterodactyl-wings && docker compose up -d
```

## Update from GitHub (keeps your .env and data)

One line — pulls the new files, the new images, and restarts:
```
cd ~/pterodactyl-wings && ./deploy-update.sh https://github.com/AngelGonePro/pterodactyl-panel-docker/raw/refs/heads/main/pterodactyl-wings.zip . && docker compose pull && docker compose up -d --remove-orphans
```
`deploy-update.sh` never touches `.env` or your server data. It appends any new `.env` keys at the bottom for you to review, and leaves any file you hand-edited alone (it reports those instead).

## Resource limits

`WINGS_MEM_LIMIT` / `WINGS_CPUS` cap the Wings daemon only. Game servers are separate containers that Wings creates, so their memory and CPU are set per server in the panel (**Server → Build Configuration**). Swap is disabled for the Wings container. After editing: `docker compose up -d`.

## Notes

- Use the panel's LAN IP for `PANEL_URL` when both are on the same network (a public Cloudflare-proxied domain can fail to hairpin and show as HTTP 502).
- `WINGS_EXTRA_ORIGINS` lists every address you open the panel from in a browser, otherwise the node heart stays red.
- `WINGS_TRUSTED_PROXIES` is the LAN IP of the proxy in front of Wings, so real visitor IPs reach Wings.
