#!/bin/sh
# Usage: ./deploy-update.sh <zip-url> <target-dir>
#
# Safely fetches a fresh zip and applies it to an EXISTING deployment.
# Two categories of file are never touched by a plain overwrite:
#
# 1. Genuine runtime state (certs, nginx-ui's database, ban history,
#    logs) — hard-protected below, always, no exceptions, since there's
#    no meaningful "template" for these to diff against.
#
# 2. Anything else you've hand-edited since the last update (frpc.toml,
#    frps.toml, or any future config file) — detected automatically by
#    comparing against a baseline snapshot of what the template looked
#    like last time this ran, not a hardcoded list of filenames. If a
#    file matches its baseline, you haven't touched it, so it's safe to
#    update normally. If it differs, you edited it, so it's left alone
#    and reported instead of silently overwritten. First run ever has
#    no baseline yet, so nothing pre-existing is touched — only files
#    that don't already exist get created.
set -eu

for cmd in curl python3; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "Missing dependency: $cmd" >&2
    echo "Install it first: sudo apt update && sudo apt install -y $cmd" >&2
    exit 1
  fi
done

ZIP_URL="${1:?Usage: $0 <zip-url> <target-dir>}"
TARGET_DIR="${2:?Usage: $0 <zip-url> <target-dir>}"

if [ "$(basename "$PWD")" = "$TARGET_DIR" ] && { [ -f "docker-compose.yml" ] || [ -f ".env" ]; }; then
  echo "You're already inside a directory named '$TARGET_DIR' with an existing deployment in it — using '.' instead of creating a nested '$TARGET_DIR/$TARGET_DIR/'." >&2
  TARGET_DIR="."
fi

# Genuine runtime state only — never has a "template" to diff against,
# so it's excluded from the baseline mechanism entirely rather than
# relying on that comparison to protect it. This script itself is here
# too, but for a different reason: it must never modify itself while
# it's the one currently running, regardless of whether it's "changed
# since baseline" — a self-overwrite mid-execution corrupts the running
# process (confirmed the hard way).
HARD_PROTECTED_PATHS="
nginx-conf
nginx-ui-data
certbot/certs
certbot/logs
certbot/www
fail2ban/data
fail2ban/jail.d/00-ignoreip.local
nginx-logs
logrotate/state
deploy-update.sh
.env
.env.last-good
update-failures.log
"
BASELINE_DIR="$TARGET_DIR/.deploy-baseline"

is_hard_protected() {
  path="$1"
  for p in $HARD_PROTECTED_PATHS; do
    case "$path" in
      "$p"|"$p"/*) return 0 ;;
    esac
  done
  return 1
}

TMP_ZIP=$(mktemp)
TMP_EXTRACT=$(mktemp -d)
trap 'rm -f "$TMP_ZIP"; rm -rf "$TMP_EXTRACT"' EXIT

echo "==> Downloading $ZIP_URL"
curl -fsSL -o "$TMP_ZIP" "$ZIP_URL"

echo "==> Extracting (stripping the top-level folder, matching your existing convention)"
python3 - "$TMP_ZIP" "$TMP_EXTRACT" << 'PYEOF'
import zipfile, os, sys
zip_path, extract_to = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(zip_path) as z:
    for member in z.namelist():
        parts = member.split("/", 1)
        if len(parts) > 1 and parts[1]:
            target = os.path.join(extract_to, parts[1])
            if not member.endswith("/"):
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with open(target, "wb") as f:
                    f.write(z.read(member))
PYEOF

mkdir -p "$TARGET_DIR" "$BASELINE_DIR"

echo "==> Applying updates"
MODIFIED_FILES=""
NEW_FILES=""
( cd "$TMP_EXTRACT" && find . -type f ) | sed 's#^\./##' | while IFS= read -r relpath; do
  if is_hard_protected "$relpath"; then
    continue
  fi

  target_file="$TARGET_DIR/$relpath"
  baseline_file="$BASELINE_DIR/$relpath"
  new_file="$TMP_EXTRACT/$relpath"

  if [ ! -e "$target_file" ]; then
    # Doesn't exist yet — always safe, nothing to protect.
    mkdir -p "$TARGET_DIR/$(dirname "$relpath")"
    cp "$new_file" "$target_file"
    echo "$relpath" >> /tmp/deploy_new_files.$$
  elif [ -f "$baseline_file" ] && cmp -s "$target_file" "$baseline_file"; then
    # Matches what we last applied — you haven't touched it since,
    # safe to update normally.
    mkdir -p "$TARGET_DIR/$(dirname "$relpath")"
    cp "$new_file" "$target_file"
  elif [ -f "$baseline_file" ]; then
    # Differs from what we last applied — you edited it since. Leave
    # it alone. Baseline still advances below to the current template,
    # so the diff shown is against what you'd actually get if you did
    # sync, and a genuine revert-to-template on your end is correctly
    # recognized as "safe again" on the next run.
    echo "$relpath" >> /tmp/deploy_edited_files.$$
  else
    # No baseline yet for a pre-existing file — this is the very first
    # time this mechanism has compared it. We don't know yet whether
    # it's hand-edited or just happens to already match what's being
    # shipped, so this one run leaves it alone rather than guess wrong
    # (this is what protects a real hand-edited frpc.toml the first
    # time this runs on an existing deployment). Baseline gets
    # established below either way, so from the NEXT run onward this
    # file is tracked normally: if it already matched, it starts
    # updating normally from here on; if it didn't, it's now correctly
    # flagged as edited going forward too.
    echo "$relpath" >> /tmp/deploy_untracked_files.$$
  fi

  mkdir -p "$BASELINE_DIR/$(dirname "$relpath")"
  cp "$new_file" "$baseline_file"
done

if [ -f /tmp/deploy_new_files.$$ ]; then
  echo "    New files added:"
  sed 's/^/      /' /tmp/deploy_new_files.$$
  rm -f /tmp/deploy_new_files.$$
fi

if [ -f /tmp/deploy_edited_files.$$ ]; then
  echo "    Hand-edited by you since the last update — left untouched. Diff against what was"
  echo "    last actually applied to see exactly what you changed:"
  while IFS= read -r f; do
    echo "      diff $TARGET_DIR/$f $BASELINE_DIR/$f"
  done < /tmp/deploy_edited_files.$$
  rm -f /tmp/deploy_edited_files.$$
fi

if [ -f /tmp/deploy_untracked_files.$$ ]; then
  echo "    First time comparing these against a template — left alone this one time in case"
  echo "    they're hand-edited; tracked normally from the next update onward:"
  sed 's/^/      /' /tmp/deploy_untracked_files.$$
  rm -f /tmp/deploy_untracked_files.$$
fi

echo "==> Checking for files/folders this update removed (nothing auto-deleted — reported only)"
if [ -d "$TARGET_DIR" ]; then
  ORPHAN_LIST=""
  for entry in "$TARGET_DIR"/* "$TARGET_DIR"/.[!.]*; do
    [ -e "$entry" ] || continue
    name=$(basename "$entry")
    case "$name" in
      deploy-update.sh|.env|.env.last-good|update-failures.log|.deploy-baseline) continue ;;
    esac
    if is_hard_protected "$name"; then
      continue
    fi
    if [ ! -e "$TMP_EXTRACT/$name" ]; then
      ORPHAN_LIST="${ORPHAN_LIST}${name}
"
    fi
  done
  if [ -n "$ORPHAN_LIST" ]; then
    echo "    No longer part of the project — safe to remove, nothing deleted automatically:"
    printf '%s' "$ORPHAN_LIST" | sed 's/^/      /'
    echo "    e.g.:"
    printf '%s' "$ORPHAN_LIST" | sed "s#^#      rm -rf $TARGET_DIR/#"
  else
    echo "    Nothing orphaned."
  fi
fi

echo "==> Merging .env"
if [ -f "$TARGET_DIR/.env" ] && [ -f "$TMP_EXTRACT/.env" ]; then
  NEW_KEYS=""
  while IFS= read -r line; do
    case "$line" in
      \#*|"") continue ;;
    esac
    key=$(echo "$line" | cut -d= -f1)
    if ! grep -q "^${key}=" "$TARGET_DIR/.env" 2>/dev/null; then
      NEW_KEYS="${NEW_KEYS}${line}
"
    fi
  done < "$TMP_EXTRACT/.env"

  if [ -n "$NEW_KEYS" ]; then
    {
      echo ""
      echo "# --- New in this update ($(date -u +'%Y-%m-%dT%H:%M:%SZ')) — review these ---"
      printf '%s' "$NEW_KEYS"
    } >> "$TARGET_DIR/.env"
    echo "    New .env keys added (defaults from the template) — review the bottom of $TARGET_DIR/.env:"
    printf '%s' "$NEW_KEYS" | grep -v '^#' | grep -v '^$' | sed 's/^/      /'
  else
    echo "    No new .env keys — nothing to add."
  fi
  echo "    All your existing values were left exactly as they were."

  OBSOLETE_KEYS=""
  while IFS= read -r line; do
    case "$line" in
      \#*|"") continue ;;
    esac
    key=$(echo "$line" | cut -d= -f1)
    if ! grep -q "^${key}=" "$TMP_EXTRACT/.env" 2>/dev/null; then
      OBSOLETE_KEYS="${OBSOLETE_KEYS}${key}
"
    fi
  done < "$TARGET_DIR/.env"
  if [ -n "$OBSOLETE_KEYS" ]; then
    echo "    These .env keys are no longer used by the current template — left in place (not"
    echo "    deleted automatically), safe to remove once you've confirmed you don't need them:"
    printf '%s' "$OBSOLETE_KEYS" | sed 's/^/      /'
  fi
elif [ -f "$TMP_EXTRACT/.env" ]; then
  cp "$TMP_EXTRACT/.env" "$TARGET_DIR/.env"
  echo "    No existing .env found — copied the template as a starting point. Fill in your real values before deploying."
fi

echo ""
echo "==> Done. Review any hand-edited files and new .env keys, then run:"
echo "    cd $TARGET_DIR && docker compose up -d --build --remove-orphans"
