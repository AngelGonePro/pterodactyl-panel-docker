#!/bin/sh
# copytruncate is required for both log groups above — nginx and certbot
# hold their log files open for the life of the process, so a normal
# rename-and-reopen rotation would leave them writing into a now-unlinked
# file that never frees its disk space. copytruncate avoids that at the
# cost of a small window where a few log lines could be lost mid-rotate,
# an acceptable tradeoff for access/debug logs.
set -eu
while true; do
  logrotate /etc/logrotate.d/project-logs --state /var/lib/logrotate/status
  sleep 3600
done
