#!/bin/sh
set -eu

IP="$1"
DENYLIST="/nginx-conf-shared/conf.d/fail2ban-denylist.conf"
ESCAPED_IP=$(printf '%s' "$IP" | sed 's/\./\\./g')

if [ -f "$DENYLIST" ]; then
  sed -i "/deny ${ESCAPED_IP};/d" "$DENYLIST"
fi

docker exec nginx-ui nginx -s reload
